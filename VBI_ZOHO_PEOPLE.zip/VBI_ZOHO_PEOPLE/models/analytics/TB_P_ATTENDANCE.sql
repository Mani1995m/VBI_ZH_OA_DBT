{{
    config(
        materialized = 'incremental',
        unique_key = 'RECORDID' 
    )
}}

Select 
    SRC:"ApprovalStatus"::varchar(30) as APPROVAL_STATUS,
    to_date(SRC:"Attendance Day"::String , 'DD-Mon-YYYY') as ATTENDANCE_DAY,
    SRC:"Break Time"::Time as BREAK_TIME,
    SRC:"Description"::varchar(15) as DESCRIPTIONS,
    SRC:"Deviation Time"::Time as DEVIATION_TIME,
    SRC:"Employee ID"::varchar(80) as EMPLOYEE_ID,
    to_timestamp(SRC:"Expected FromTime"::String, 'DD-MON-YYYY HH:MI:SS') as EXPECTED_FROMTIME,
    to_timestamp(SRC:"Expected ToTime"::String, 'DD-MON-YYYY HH:MI:SS') as EXPECTED_TOTIME,
    to_timestamp(SRC:"From Time"::String, 'DD-MON-YYYY HH:MI:SS') as FROM_TIME,
    SRC:"InputType"::varchar(15) as INPUT_TYPE,
    SRC:"Over Time"::varchar(50) as OVER_TIME,
    SRC:"New Project Lead"::varchar(80) as NEW_PROJECT_LEAD,
    SRC:"Post Project Feedback to be filled by"::varchar(80) as POST_PROJECT_FEEDBACK_TO_BE_FILLED_BY,
    SRC:"Project Lead"::varchar(80) as PROJECT_LEAD,
    SRC:"Project Name"::varchar(80) as PROJECT_NAME,
    SRC:"Reasons for Department Change"::varchar(250) as REASONS_FOR_DEPARTMENT_CHANGE,
    SRC:"createdTime"::varchar(15) as CREATED_TIME_INT, 
    SRC:"modifiedTime"::varchar(15) as MODIFIED_TIME_INT,  
    to_timestamp_ntz(MODIFIED_TIME_INT::BIGINT,3) as MODIFIED_TIME,
    SRC:"ownerID"::varchar(30) as OWNER_ID,    
    SRC:"ownerName"::varchar(80) as OWNER_NAME,
    SRC:"recordId"::varchar(20) as RECORDID
    
from {{ source('ZOHO_PEOPLE_VIEW', 'TB_HIST_PROJECT_DEPARTMENT_CHANGES_VIEW')}}

{% if is_incremental() %}
    where MODIFIED_TIME > ( select max(MODIFIED_TIME) from {{ this }} )
{% endif %}